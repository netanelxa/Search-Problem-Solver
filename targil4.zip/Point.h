//
// Created by netanel on 19/01/2020.
//

#ifndef EX4_POINT_H
#define EX4_POINT_H


class Point {
    int x;
    int y;
public:
    Point(int x, int y);

    int getX();

    int getY();

    void setX(int x);

    void setY(int y);

};


#endif //EX4_POINT_H
